/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['i.scdn.co', 'mosaic.scdn.co', 'lineup-images.scdn.co', 'seeded-session-images.scdn.co'],
  },
}

module.exports = nextConfig
