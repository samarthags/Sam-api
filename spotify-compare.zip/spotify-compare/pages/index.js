import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';
import { computeCompatibility } from '../lib/spotify';

// ─── tiny helpers ──────────────────────────────────────────────────────────────
const img = (arr, size = 0) => arr?.[size]?.url || arr?.[0]?.url || null;

function scoreLabel(n) {
  if (n >= 85) return { text: 'Soulmates 💞', color: '#ff6b9d' };
  if (n >= 70) return { text: 'Best Friends 🎶', color: '#a855f7' };
  if (n >= 55) return { text: 'Good Vibes ✨', color: '#1DB954' };
  if (n >= 40) return { text: 'Interesting Mix 🎵', color: '#3b82f6' };
  if (n >= 25) return { text: 'Opposites Attract 🔥', color: '#f97316' };
  return { text: 'Musical Strangers 🌍', color: '#6b6b8a' };
}

// ─── sub-components ────────────────────────────────────────────────────────────
function Spinner() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
      <div className="spinner" />
      <style>{`.spinner{width:36px;height:36px;border:3px solid rgba(255,255,255,.08);border-top-color:#1DB954;border-radius:50%;animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

function UserCard({ slot, user, onLogin, loading }) {
  const isUser1 = slot === 'user1';
  const accent = isUser1 ? '#1DB954' : '#a855f7';

  if (!user && !loading) {
    return (
      <div className="user-slot empty" style={{ '--accent': accent }}>
        <div className="slot-inner">
          <div className="slot-avatar-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
              <circle cx="12" cy="7" r="4"/>
            </svg>
          </div>
          <p className="slot-label">{isUser1 ? 'First Person' : 'Second Person'}</p>
          <button className="connect-btn" onClick={() => onLogin(slot)}>
            Connect Spotify
          </button>
        </div>
        <style>{`
          .user-slot.empty{background:var(--card);border:1.5px dashed rgba(255,255,255,.1);border-radius:20px;padding:32px 24px;display:flex;align-items:center;justify-content:center;transition:border-color .3s}
          .user-slot.empty:hover{border-color:var(--accent)}
          .slot-inner{text-align:center;display:flex;flex-direction:column;align-items:center;gap:16px}
          .slot-avatar-placeholder{width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;color:var(--muted)}
          .slot-label{font-family:var(--font-display);font-size:14px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}
          .connect-btn{background:var(--accent);color:#000;border:none;padding:12px 24px;border-radius:50px;font-family:var(--font-display);font-weight:700;font-size:14px;cursor:pointer;transition:transform .2s,box-shadow .2s}
          .connect-btn:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.3)}
        `}</style>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="user-slot loading" style={{ '--accent': accent }}>
        <Spinner />
        <style>{`.user-slot.loading{background:var(--card);border-radius:20px;padding:32px 24px;min-height:200px;display:flex;align-items:center;justify-content:center}`}</style>
      </div>
    );
  }

  const { profile, topTracks, topArtists } = user;
  const topTrack = topTracks?.short?.[0];
  const topArtist = topArtists?.short?.[0];

  return (
    <div className="user-slot filled" style={{ '--accent': accent }}>
      <div className="user-header">
        {profile.images?.[0]?.url ? (
          <img src={profile.images[0].url} alt={profile.display_name} className="user-avatar" />
        ) : (
          <div className="user-avatar-fallback">{profile.display_name?.[0] || '?'}</div>
        )}
        <div>
          <h3 className="user-name">{profile.display_name}</h3>
          <p className="user-meta">{profile.followers?.total?.toLocaleString()} followers</p>
        </div>
        <button className="logout-btn" onClick={() => onLogin(slot)} title="Switch account">↻</button>
      </div>

      {topArtist && (
        <div className="top-item">
          <span className="top-item-label">Top Artist</span>
          <div className="top-item-content">
            {img(topArtist.images) && <img src={img(topArtist.images)} alt={topArtist.name} className="top-item-img" />}
            <span>{topArtist.name}</span>
          </div>
        </div>
      )}

      {topTrack && (
        <div className="top-item">
          <span className="top-item-label">Top Track</span>
          <div className="top-item-content">
            {img(topTrack.album?.images) && <img src={img(topTrack.album.images)} alt={topTrack.name} className="top-item-img" />}
            <span>{topTrack.name}</span>
          </div>
        </div>
      )}

      <style>{`
        .user-slot.filled{background:var(--card);border-radius:20px;padding:24px;border:1.5px solid var(--border);position:relative}
        .user-slot.filled::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:20px 20px 0 0;background:var(--accent)}
        .user-header{display:flex;align-items:center;gap:14px;margin-bottom:20px}
        .user-avatar{width:56px;height:56px;border-radius:50%;object-fit:cover;border:2px solid var(--accent)}
        .user-avatar-fallback{width:56px;height:56px;border-radius:50%;background:var(--card2);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:22px;font-weight:700;border:2px solid var(--accent)}
        .user-name{font-family:var(--font-display);font-size:18px;font-weight:700}
        .user-meta{font-size:12px;color:var(--muted);margin-top:2px}
        .logout-btn{margin-left:auto;background:rgba(255,255,255,.05);border:none;color:var(--muted);width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:background .2s}
        .logout-btn:hover{background:rgba(255,255,255,.1);color:#fff}
        .top-item{background:var(--bg2);border-radius:12px;padding:12px 14px;margin-bottom:10px}
        .top-item-label{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);font-weight:600;display:block;margin-bottom:8px}
        .top-item-content{display:flex;align-items:center;gap:10px;font-size:14px;font-weight:500}
        .top-item-img{width:36px;height:36px;border-radius:6px;object-fit:cover}
      `}</style>
    </div>
  );
}

function ScoreRing({ score }) {
  const { text, color } = scoreLabel(score);
  const r = 54;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;

  return (
    <div className="score-ring-wrap">
      <svg width="140" height="140" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(255,255,255,.06)" strokeWidth="10" />
        <circle
          cx="70" cy="70" r={r}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circ}`}
          strokeDashoffset={circ / 4}
          style={{ filter: `drop-shadow(0 0 8px ${color})`, transition: 'stroke-dasharray 1.2s cubic-bezier(.4,0,.2,1)' }}
        />
        <text x="70" y="65" textAnchor="middle" fill="#fff" fontSize="28" fontFamily="Syne" fontWeight="800">{score}%</text>
        <text x="70" y="84" textAnchor="middle" fill="rgba(255,255,255,.5)" fontSize="11" fontFamily="DM Sans">match</text>
      </svg>
      <p className="score-label" style={{ color }}>{text}</p>
      <style>{`.score-ring-wrap{display:flex;flex-direction:column;align-items:center;gap:8px}.score-label{font-family:var(--font-display);font-size:16px;font-weight:700;text-align:center}`}</style>
    </div>
  );
}

function BreakdownBar({ label, value, color }) {
  return (
    <div className="bar-row">
      <span className="bar-label">{label}</span>
      <div className="bar-track">
        <div className="bar-fill" style={{ width: `${value}%`, background: color, boxShadow: `0 0 10px ${color}40` }} />
      </div>
      <span className="bar-val">{value}%</span>
      <style>{`.bar-row{display:flex;align-items:center;gap:12px;margin-bottom:12px}.bar-label{font-size:13px;font-weight:500;width:60px;color:var(--muted)}.bar-track{flex:1;height:8px;background:rgba(255,255,255,.06);border-radius:99px;overflow:hidden}.bar-fill{height:100%;border-radius:99px;transition:width 1s cubic-bezier(.4,0,.2,1)}.bar-val{font-size:13px;font-weight:700;width:36px;text-align:right}`}</style>
    </div>
  );
}

function TrackRow({ track, rank }) {
  const albumImg = img(track.album?.images, 2) || img(track.album?.images);
  return (
    <div className="track-row">
      <span className="rank">{rank}</span>
      {albumImg && <img src={albumImg} alt={track.name} className="track-img" />}
      <div className="track-info">
        <p className="track-name">{track.name}</p>
        <p className="track-artist">{track.artists?.map(a => a.name).join(', ')}</p>
      </div>
      <style>{`.track-row{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)}.track-row:last-child{border-bottom:none}.rank{font-family:var(--font-display);font-size:12px;font-weight:700;color:var(--muted);width:20px;text-align:center}.track-img{width:44px;height:44px;border-radius:8px;object-fit:cover}.track-info{flex:1;min-width:0}.track-name{font-size:14px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.track-artist{font-size:12px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}`}</style>
    </div>
  );
}

function ArtistPill({ artist }) {
  const artistImg = img(artist.images, 2) || img(artist.images);
  return (
    <div className="artist-pill">
      {artistImg ? <img src={artistImg} alt={artist.name} className="pill-img" /> : <div className="pill-img pill-fallback">{artist.name[0]}</div>}
      <span>{artist.name}</span>
      <style>{`.artist-pill{display:flex;align-items:center;gap:8px;background:var(--card2);padding:6px 12px 6px 6px;border-radius:50px;font-size:13px;font-weight:500;white-space:nowrap}.pill-img{width:28px;height:28px;border-radius:50%;object-fit:cover}.pill-fallback{background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700}`}</style>
    </div>
  );
}

function GenreTag({ genre, shared }) {
  return (
    <span className={`genre-tag ${shared ? 'shared' : ''}`}>
      {shared && '♥ '}{genre}
      <style>{`.genre-tag{display:inline-block;padding:4px 12px;border-radius:99px;font-size:12px;font-weight:500;background:rgba(255,255,255,.06);color:var(--muted);margin:4px}.genre-tag.shared{background:rgba(29,185,84,.12);color:#1DB954;border:1px solid rgba(29,185,84,.25)}`}</style>
    </span>
  );
}

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function Home() {
  const [users, setUsers] = useState({ user1: null, user2: null });
  const [loading, setLoading] = useState({ user1: false, user2: false });
  const [compat, setCompat] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [error, setError] = useState('');

  // Load tokens from sessionStorage on mount
  useEffect(() => {
    ['user1', 'user2'].forEach(slot => {
      const token = sessionStorage.getItem(`${slot}_access_token`);
      if (token) fetchUserData(slot, token);
    });
  }, []);

  async function fetchUserData(slot, token) {
    setLoading(prev => ({ ...prev, [slot]: true }));
    try {
      const res = await fetch(`/api/user-data?access_token=${token}`);
      if (!res.ok) throw new Error('Failed');
      const data = await res.json();
      setUsers(prev => {
        const next = { ...prev, [slot]: data };
        // Compute compat if both loaded
        const other = slot === 'user1' ? prev.user2 : prev.user1;
        const me = data;
        if (other && me) {
          setCompat(computeCompatibility(
            slot === 'user1' ? me : other,
            slot === 'user1' ? other : me
          ));
        }
        return next;
      });
    } catch (e) {
      setError('Could not load Spotify data. Please reconnect.');
      sessionStorage.removeItem(`${slot}_access_token`);
    } finally {
      setLoading(prev => ({ ...prev, [slot]: false }));
    }
  }

  // Recompute compat when both users loaded
  useEffect(() => {
    if (users.user1 && users.user2) {
      setCompat(computeCompatibility(users.user1, users.user2));
    } else {
      setCompat(null);
    }
  }, [users.user1, users.user2]);

  async function handleLogin(slot) {
    // Clear existing
    sessionStorage.removeItem(`${slot}_access_token`);
    setUsers(prev => ({ ...prev, [slot]: null }));
    setCompat(null);
    const res = await fetch(`/api/auth-url?slot=${slot}`);
    const { url } = await res.json();
    window.location.href = url;
  }

  const bothConnected = users.user1 && users.user2;

  return (
    <>
      <Head>
        <title>Sammu — Spotify Compatibility</title>
        <meta name="description" content="Discover your music compatibility with friends, lovers, and more" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎵</text></svg>" />
      </Head>

      <div className="page">
        {/* Background */}
        <div className="bg-mesh" />

        {/* Header */}
        <header className="header">
          <div className="logo">
            <span className="logo-icon">♫</span>
            <span className="logo-text">sammu</span>
          </div>
          <p className="tagline">your music, your match</p>
        </header>

        <main className="main">
          {error && (
            <div className="error-banner">⚠ {error} <button onClick={() => setError('')}>✕</button></div>
          )}

          {/* User cards */}
          <section className="users-section">
            <UserCard slot="user1" user={users.user1} onLogin={handleLogin} loading={loading.user1} />
            <div className="vs-divider">
              {compat ? <ScoreRing score={compat.overall} /> : (
                <div className="vs-text">
                  <span>VS</span>
                  <p>Connect both accounts</p>
                </div>
              )}
            </div>
            <UserCard slot="user2" user={users.user2} onLogin={handleLogin} loading={loading.user2} />
          </section>

          {/* Results */}
          {bothConnected && compat && (
            <section className="results-section">
              {/* Tab nav */}
              <div className="tabs">
                {['overview', 'artists', 'tracks', 'genres'].map(tab => (
                  <button key={tab} className={`tab ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              {/* Overview */}
              {activeTab === 'overview' && (
                <div className="tab-content">
                  <div className="breakdown-card">
                    <h3 className="card-title">Compatibility Breakdown</h3>
                    <BreakdownBar label="Artists" value={compat.breakdown.artists} color="#1DB954" />
                    <BreakdownBar label="Tracks" value={compat.breakdown.tracks} color="#a855f7" />
                    <BreakdownBar label="Genres" value={compat.breakdown.genres} color="#3b82f6" />
                  </div>

                  {compat.sharedArtists.length > 0 && (
                    <div className="info-card">
                      <h3 className="card-title">Artists You Both Love</h3>
                      <div className="pills-wrap">
                        {compat.sharedArtists.slice(0, 6).map(a => <ArtistPill key={a.id} artist={a} />)}
                      </div>
                    </div>
                  )}

                  {compat.sharedGenres.length > 0 && (
                    <div className="info-card">
                      <h3 className="card-title">Shared Genres</h3>
                      <div>
                        {compat.sharedGenres.map(g => <GenreTag key={g} genre={g} shared />)}
                      </div>
                    </div>
                  )}

                  <div className="two-col">
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#1DB954' }}>{users.user1.profile.display_name}'s Taste</h3>
                      {compat.topGenres1.map(g => <GenreTag key={g} genre={g} />)}
                    </div>
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#a855f7' }}>{users.user2.profile.display_name}'s Taste</h3>
                      {compat.topGenres2.map(g => <GenreTag key={g} genre={g} />)}
                    </div>
                  </div>
                </div>
              )}

              {/* Artists tab */}
              {activeTab === 'artists' && (
                <div className="tab-content">
                  <div className="two-col">
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#1DB954' }}>{users.user1.profile.display_name}</h3>
                      {users.user1.topArtists.short.slice(0, 10).map((a, i) => (
                        <div key={a.id} className="artist-row">
                          <span className="rank">{i + 1}</span>
                          {img(a.images) && <img src={img(a.images, 2) || img(a.images)} className="ar-img" alt={a.name} />}
                          <div>
                            <p className="ar-name">{a.name}</p>
                            <p className="ar-genre">{a.genres?.[0]}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#a855f7' }}>{users.user2.profile.display_name}</h3>
                      {users.user2.topArtists.short.slice(0, 10).map((a, i) => (
                        <div key={a.id} className="artist-row">
                          <span className="rank">{i + 1}</span>
                          {img(a.images) && <img src={img(a.images, 2) || img(a.images)} className="ar-img" alt={a.name} />}
                          <div>
                            <p className="ar-name">{a.name}</p>
                            <p className="ar-genre">{a.genres?.[0]}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {compat.sharedArtists.length > 0 && (
                    <div className="info-card">
                      <h3 className="card-title">Artists You Both Have in Top 50</h3>
                      <div className="pills-wrap">
                        {compat.sharedArtists.map(a => <ArtistPill key={a.id} artist={a} />)}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Tracks tab */}
              {activeTab === 'tracks' && (
                <div className="tab-content">
                  <div className="two-col">
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#1DB954' }}>{users.user1.profile.display_name}</h3>
                      {users.user1.topTracks.short.slice(0, 12).map((t, i) => <TrackRow key={t.id} track={t} rank={i + 1} />)}
                    </div>
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#a855f7' }}>{users.user2.profile.display_name}</h3>
                      {users.user2.topTracks.short.slice(0, 12).map((t, i) => <TrackRow key={t.id} track={t} rank={i + 1} />)}
                    </div>
                  </div>
                  {compat.sharedTracks.length > 0 && (
                    <div className="info-card">
                      <h3 className="card-title">Tracks You Both Have in Top 50 🎵</h3>
                      {compat.sharedTracks.map((t, i) => <TrackRow key={t.id} track={t} rank={i + 1} />)}
                    </div>
                  )}
                  {compat.sharedTracks.length === 0 && (
                    <div className="info-card" style={{ textAlign: 'center', color: 'var(--muted)', padding: '32px' }}>
                      <p style={{ fontSize: 32, marginBottom: 8 }}>🎲</p>
                      <p>No tracks in common — totally different tastes!</p>
                    </div>
                  )}
                </div>
              )}

              {/* Genres tab */}
              {activeTab === 'genres' && (
                <div className="tab-content">
                  {compat.sharedGenres.length > 0 && (
                    <div className="info-card">
                      <h3 className="card-title">Genres You Share ♥</h3>
                      <div style={{ paddingTop: 8 }}>
                        {compat.sharedGenres.map(g => <GenreTag key={g} genre={g} shared />)}
                      </div>
                    </div>
                  )}
                  <div className="two-col">
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#1DB954' }}>{users.user1.profile.display_name}'s Genres</h3>
                      {compat.topGenres1.map(g => <GenreTag key={g} genre={g} />)}
                    </div>
                    <div className="info-card">
                      <h3 className="card-title" style={{ color: '#a855f7' }}>{users.user2.profile.display_name}'s Genres</h3>
                      {compat.topGenres2.map(g => <GenreTag key={g} genre={g} />)}
                    </div>
                  </div>
                </div>
              )}
            </section>
          )}

          {/* CTA when only one connected */}
          {(users.user1 || users.user2) && !(users.user1 && users.user2) && (
            <div className="cta-banner">
              <p>🎵 Now connect the second account to see your music compatibility!</p>
            </div>
          )}

          {/* Landing copy when none connected */}
          {!users.user1 && !users.user2 && (
            <div className="landing-copy">
              <h2>Discover your music bond</h2>
              <p>Connect two Spotify accounts — friends, partners, siblings, anyone — and see how your musical worlds collide.</p>
              <div className="feature-pills">
                <span>💞 Lovers</span>
                <span>👯 Best Friends</span>
                <span>🎸 Band Members</span>
                <span>👨‍👩‍👧 Family</span>
              </div>
            </div>
          )}
        </main>
      </div>

      <style jsx global>{`
        .page{min-height:100vh;position:relative}
        .bg-mesh{position:fixed;inset:0;pointer-events:none;z-index:0;background:radial-gradient(ellipse 80% 60% at 20% -10%,rgba(29,185,84,.07) 0,transparent 60%),radial-gradient(ellipse 60% 50% at 80% 110%,rgba(168,85,247,.07) 0,transparent 60%)}
        .header{position:relative;z-index:1;text-align:center;padding:48px 24px 24px}
        .logo{display:inline-flex;align-items:center;gap:10px;margin-bottom:8px}
        .logo-icon{font-size:28px;color:#1DB954}
        .logo-text{font-family:var(--font-display);font-size:32px;font-weight:800;letter-spacing:-.02em;background:linear-gradient(135deg,#fff 0%,rgba(255,255,255,.6) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .tagline{font-size:14px;color:var(--muted);font-style:italic}
        .main{position:relative;z-index:1;max-width:1100px;margin:0 auto;padding:0 20px 80px}
        .error-banner{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;padding:12px 16px;border-radius:12px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center}
        .error-banner button{background:none;border:none;color:inherit;cursor:pointer;font-size:16px}
        .users-section{display:grid;grid-template-columns:1fr auto 1fr;gap:24px;align-items:center;margin-bottom:40px}
        @media(max-width:700px){.users-section{grid-template-columns:1fr;gap:16px}}
        .vs-divider{display:flex;align-items:center;justify-content:center}
        .vs-text{text-align:center}
        .vs-text span{font-family:var(--font-display);font-size:28px;font-weight:800;color:rgba(255,255,255,.15)}
        .vs-text p{font-size:11px;color:var(--muted);margin-top:4px;white-space:nowrap}
        .results-section{animation:fadeUp .5s ease}
        @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
        .tabs{display:flex;gap:4px;background:var(--card);padding:6px;border-radius:16px;margin-bottom:24px;width:fit-content}
        .tab{background:none;border:none;color:var(--muted);padding:10px 20px;border-radius:12px;font-family:var(--font-display);font-weight:600;font-size:14px;cursor:pointer;transition:all .2s}
        .tab.active{background:var(--card2);color:#fff}
        .tab-content{display:flex;flex-direction:column;gap:20px}
        .breakdown-card,.info-card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:24px}
        .card-title{font-family:var(--font-display);font-size:15px;font-weight:700;margin-bottom:16px;color:rgba(255,255,255,.8)}
        .pills-wrap{display:flex;flex-wrap:wrap;gap:8px}
        .two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px}
        @media(max-width:700px){.two-col{grid-template-columns:1fr}}
        .artist-row{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)}
        .artist-row:last-child{border-bottom:none}
        .rank{font-family:var(--font-display);font-size:12px;font-weight:700;color:var(--muted);width:18px}
        .ar-img{width:40px;height:40px;border-radius:50%;object-fit:cover}
        .ar-name{font-size:14px;font-weight:500}
        .ar-genre{font-size:11px;color:var(--muted);margin-top:2px}
        .cta-banner{background:linear-gradient(135deg,rgba(29,185,84,.1),rgba(168,85,247,.1));border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:24px;text-align:center;font-size:15px;color:rgba(255,255,255,.7)}
        .landing-copy{text-align:center;padding:40px 20px;max-width:480px;margin:0 auto}
        .landing-copy h2{font-family:var(--font-display);font-size:28px;font-weight:800;margin-bottom:12px}
        .landing-copy p{font-size:15px;color:var(--muted);line-height:1.7}
        .feature-pills{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin-top:24px}
        .feature-pills span{background:var(--card);border:1px solid var(--border);padding:8px 16px;border-radius:50px;font-size:13px;font-weight:500}
      `}</style>
    </>
  );
}
