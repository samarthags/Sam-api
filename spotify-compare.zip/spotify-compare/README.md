# 🎵 Sammu — Spotify Compatibility App

Compare music tastes between two Spotify users. Perfect for friends, lovers, bandmates, or anyone curious about their music bond.

## Features
- 🎧 Connect two Spotify accounts independently
- 💯 Overall compatibility score (0–99%)
- 📊 Breakdown by artists, tracks, and genres
- 🎨 Shared artists & tracks highlighted
- 🏷️ Genre taste comparison side-by-side
- 📱 Mobile-friendly responsive design

## Tech Stack
- Next.js 14 (Pages Router)
- Spotify Web API (OAuth 2.0)
- Deployed on Vercel

---

## 🚀 Deploy to Vercel

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "initial commit"
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

### 2. Import on Vercel
- Go to https://vercel.com/new
- Import your GitHub repo
- Set environment variables (see below)

### 3. Environment Variables (set in Vercel dashboard)
```
SPOTIFY_CLIENT_ID=9805e242ac154f43b66206b54707ac7a
SPOTIFY_CLIENT_SECRET=33971a107cf14e6391f7c17a758bccf0
REDIRECT_URI=https://sammuspotify.vercel.app/api/auth/callback
NEXT_PUBLIC_BASE_URL=https://sammuspotify.vercel.app
```

### 4. Spotify App Settings
In your Spotify Developer Dashboard (https://developer.spotify.com/dashboard):
- Add Redirect URI: `https://sammuspotify.vercel.app/api/auth/callback`
- Make sure the app is in "Extended Quota Mode" or add test users if in Development Mode

---

## 🔧 Local Development

```bash
npm install
npm run dev
```

For local dev, update `.env.local`:
```
REDIRECT_URI=http://localhost:3000/api/auth/callback
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```
And add `http://localhost:3000/api/auth/callback` to your Spotify app's redirect URIs.

---

## How It Works

1. User 1 clicks "Connect Spotify" → redirected to Spotify OAuth → comes back
2. User 2 does the same independently
3. App fetches both users' top artists, tracks, genres
4. Compatibility algorithm computes overlap score
5. Results shown with full breakdown

## Compatibility Score Formula
- 40% — Artist overlap (top 50 medium-term)
- 35% — Track overlap (top 50 medium-term)
- 25% — Genre overlap (derived from top artists)
